import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class LambdaExercise {

    public static List<String> method(Supplier<String> prefix, Supplier<String> whatToReturn) {

        switch (whatToReturn.get()) {

            case "field":
                Field[] fields = Person.class.getDeclaredFields();
                return Arrays.stream(fields)
                        .filter(x -> (Modifier.toString(x.getModifiers()) + " " + x.getType().getSimpleName())
                                .equals(prefix.get()))
                        .map(Field::getName).collect(Collectors.toList());

            case "method":
                Method[] methods = Person.class.getDeclaredMethods();
                return Arrays.stream(methods)
                        .filter(x -> (Modifier.toString(x.getModifiers()) + " " + x.getReturnType().getSimpleName())
                                .equals(prefix.get()))
                        .map(Method::getName).collect(Collectors.toList());

            case "constructor":

                Constructor[] constructors = Person.class.getDeclaredConstructors();
                return Arrays.stream(constructors)
                        .filter(x -> (Modifier.toString(x.getModifiers())).equals(prefix.get()))
                        .map(Constructor::toString).collect(Collectors.toList());

            default:
                return new ArrayList<>();
        }
    }

    public static void main(String[] args) throws Exception {

        String prefix = args[0].trim();
        String whatToReturn = args[1].toLowerCase().trim();

        method(() -> {
            return prefix;
        }, () -> {
            return whatToReturn;
        }).stream().forEach(System.out::println);

    }
}
